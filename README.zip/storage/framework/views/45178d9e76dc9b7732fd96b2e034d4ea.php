<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
  <div class="fade-in mb-6">
    <h2 class="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight lg:hidden">Users</h2>
    <p class="text-gray-500 text-sm mt-1">Manage admin, coordinator, and developer accounts.</p>
  </div>

  <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" class="fade-in bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8 mb-8">
    <?php echo csrf_field(); ?>
    <h3 class="font-black text-base sm:text-lg text-gray-900 mb-5">Add New User</h3>
    <div class="flex flex-wrap gap-3 items-end">
      <div class="flex-1 min-w-[160px]">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Name</label>
        <input type="text" name="name" required placeholder="Full name" class="w-full px-5 py-3.5 rounded-full border-2 border-gray-200 text-base focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200" />
      </div>
      <div class="flex-1 min-w-[180px]">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Email</label>
        <input type="email" name="email" required placeholder="name@example.com" class="w-full px-5 py-3.5 rounded-full border-2 border-gray-200 text-base focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200" />
      </div>
      <div class="flex-1 min-w-[140px]">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Phone</label>
        <input type="text" name="phone" placeholder="07X XXX XXXX" class="w-full px-5 py-3.5 rounded-full border-2 border-gray-200 text-base focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200" />
      </div>
      <div class="min-w-[150px]">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Role</label>
        <select name="role" required class="w-full px-5 py-3.5 rounded-full border-2 border-gray-200 text-base focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200">
          <option value="client">Client</option>
          <option value="coordinator">Coordinator</option>
          <option value="admin">Admin</option>
          <option value="developer">Developer</option>
        </select>
      </div>
      <div class="flex-1 min-w-[160px]">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Password</label>
        <input type="password" name="password" required minlength="6" placeholder="Min 6 characters" class="w-full px-5 py-3.5 rounded-full border-2 border-gray-200 text-base focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200" />
      </div>
      <button class="bg-brand-red hover:bg-brand-darkRed active:scale-[0.98] hover:scale-[1.02] text-white px-8 py-3.5 rounded-full font-black text-base shadow-lg shadow-brand-red/30 transition-all duration-300">Add User</button>
    </div>

    <?php if($errors->any()): ?>
      <div class="mt-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-brand-red">
        <ul class="list-disc list-inside space-y-1">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>
  </form>

  <div class="fade-in bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div x-data="{ editing: false }" class="<?php echo e(!$loop->last ? 'border-b border-gray-100' : ''); ?>">
        <!-- View mode -->
        <div x-show="!editing" class="flex items-center justify-between px-6 py-5 hover:bg-gray-50/60 transition-colors duration-200 flex-wrap gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-12 h-12 rounded-full bg-brand-red/10 text-brand-red flex items-center justify-center font-bold text-base shrink-0">
              <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

            </div>
            <div class="min-w-0">
              <p class="font-bold text-gray-900 truncate"><?php echo e($user->name); ?></p>
              <p class="text-xs text-gray-500 truncate"><?php echo e($user->email); ?> <?php if($user->phone): ?> &middot; <?php echo e($user->phone); ?> <?php endif; ?></p>
            </div>
            <span class="shrink-0 text-[10px] font-black uppercase tracking-wide px-2.5 py-1 rounded-full bg-gray-100 text-gray-600"><?php echo e($user->role); ?></span>
          </div>
          <div class="flex items-center gap-2 shrink-0">
            <button type="button" @click="editing = true" class="text-sm font-bold text-gray-600 border-2 border-gray-200 rounded-full px-5 py-2.5 hover:bg-gray-50 transition-colors duration-200">Edit</button>
            <?php if($user->id !== auth()->id()): ?>
              <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>" onsubmit="return confirm('Delete <?php echo e($user->name); ?>?');">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="w-10 h-10 flex items-center justify-center rounded-full border-2 border-red-100 text-brand-red hover:bg-red-50 transition-colors duration-200">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 7h12M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m2 0-1 13a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 7h12Z" /></svg>
                </button>
              </form>
            <?php endif; ?>
          </div>
        </div>

        <!-- Edit mode -->
        <form x-show="editing" method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>" class="flex flex-wrap items-end gap-3 px-6 py-4 bg-gray-50/60">
          <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
          <div class="flex-1 min-w-[160px]">
            <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Name</label>
            <input type="text" name="name" value="<?php echo e($user->name); ?>" required class="w-full px-4 py-2.5 rounded-full border-2 border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/15 focus:border-brand-red" />
          </div>
          <div class="flex-1 min-w-[180px]">
            <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Email</label>
            <input type="email" name="email" value="<?php echo e($user->email); ?>" required class="w-full px-4 py-2.5 rounded-full border-2 border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/15 focus:border-brand-red" />
          </div>
          <div class="flex-1 min-w-[140px]">
            <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Phone</label>
            <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="w-full px-4 py-2.5 rounded-full border-2 border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/15 focus:border-brand-red" />
          </div>
          <div class="min-w-[150px]">
            <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Role</label>
            <select name="role" required class="w-full px-4 py-2.5 rounded-full border-2 border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/15 focus:border-brand-red">
              <?php $__currentLoopData = ['client', 'coordinator', 'admin', 'developer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role); ?>" <?php if($user->role === $role): echo 'selected'; endif; ?>><?php echo e(ucfirst($role)); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="flex-1 min-w-[160px]">
            <label class="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">New Password</label>
            <input type="password" name="password" minlength="6" placeholder="Leave blank to keep current" class="w-full px-4 py-2.5 rounded-full border-2 border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/15 focus:border-brand-red" />
          </div>
          <button type="button" @click="editing = false" class="text-sm font-bold text-gray-600 px-4 py-2.5">Cancel</button>
          <button type="submit" class="bg-brand-red hover:bg-brand-darkRed text-white text-sm font-bold rounded-full px-6 py-2.5 shadow-md shadow-brand-red/25 transition-all duration-200">Save</button>
        </form>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="px-6 py-10 text-sm text-gray-400 text-center">No users yet. Add one above.</p>
    <?php endif; ?>
  </div>
  <div class="mt-6"><?php echo e($users->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamanaTV\resources\views/admin/users/index.blade.php ENDPATH**/ ?>