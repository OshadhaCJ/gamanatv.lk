<?php $__env->startSection('title', 'Attendance'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div>
      <h2 class="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight lg:hidden">Attendance</h2>
      <p class="text-gray-500 text-sm mt-1">
        Mark each bus for <span class="font-bold text-gray-900"><?php echo e($date->format('l, F j, Y')); ?></span><?php echo e($isToday ? ' (today)' : ''); ?>.
        A bus auto-marks itself "Running" the moment a device ping comes in.
      </p>
    </div>
    <form method="GET" class="flex items-center gap-2">
      <input type="date" name="date" value="<?php echo e($date->toDateString()); ?>" onchange="this.form.submit()" class="px-5 py-3 rounded-full border-2 border-gray-200 text-sm font-semibold focus:outline-none focus:ring-4 focus:ring-brand-red/15 focus:border-brand-red transition-all duration-200" />
    </form>
  </div>

  <div class="fade-in bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $attendance = $bus->attendances->first(); ?>
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 <?php echo e(!$loop->last ? 'border-b border-gray-100' : ''); ?>">
        <div class="min-w-0">
          <p class="font-bold text-gray-900"><?php echo e($bus->number); ?><?php echo e($bus->name ? ' — '.$bus->name : ''); ?></p>
          <p class="text-xs text-gray-500"><?php echo e($bus->city->name); ?></p>
        </div>

        <div class="flex items-center gap-3 flex-wrap">
          <?php if($attendance): ?>
            <span class="text-[11px] font-black uppercase tracking-wide px-3 py-1.5 rounded-full
              <?php echo e(match($attendance->status) {
                'running' => 'bg-green-50 text-green-600',
                'holiday' => 'bg-blue-50 text-blue-600',
                'couldnt_contact' => 'bg-red-50 text-brand-red',
              }); ?>">
              <?php echo e(str_replace('_', ' ', $attendance->status)); ?>

            </span>
            <span class="text-xs text-gray-400">
              <?php echo e($attendance->auto_marked ? 'Auto-marked' : 'By '.($attendance->markedBy?->name ?? '—')); ?>

            </span>
          <?php elseif($isToday && now()->hour >= 12): ?>
            <span class="text-[11px] font-black uppercase tracking-wide px-3 py-1.5 rounded-full bg-amber-50 text-amber-600">
              Not marked — past noon
            </span>
          <?php else: ?>
            <span class="text-[11px] font-black uppercase tracking-wide px-3 py-1.5 rounded-full bg-gray-100 text-gray-400">
              Not marked yet
            </span>
          <?php endif; ?>

          <form method="POST" action="<?php echo e(route('admin.attendance.store')); ?>" class="flex items-center gap-1.5">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="bus_id" value="<?php echo e($bus->id); ?>" />
            <input type="hidden" name="date" value="<?php echo e($date->toDateString()); ?>" />
            <button type="submit" name="status" value="running" class="text-xs font-bold text-green-700 border-2 border-green-200 rounded-full px-4 py-2 hover:bg-green-50 hover:scale-105 transition-all duration-200">Running</button>
            <button type="submit" name="status" value="holiday" class="text-xs font-bold text-blue-700 border-2 border-blue-200 rounded-full px-4 py-2 hover:bg-blue-50 hover:scale-105 transition-all duration-200">Holiday</button>
            <button type="submit" name="status" value="couldnt_contact" class="text-xs font-bold text-brand-red border-2 border-red-200 rounded-full px-4 py-2 hover:bg-red-50 hover:scale-105 transition-all duration-200">Couldn't Contact</button>
          </form>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamanaTV\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>